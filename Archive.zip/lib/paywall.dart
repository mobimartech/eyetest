import 'dart:async';

import 'package:eyetest/home.dart';
import 'package:flutter/material.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PaywallScreen extends StatefulWidget {
  const PaywallScreen({Key? key}) : super(key: key);

  @override
  State<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends State<PaywallScreen>
    with SingleTickerProviderStateMixin {
  List<Package> packages = [];
  Package? selectedPackage;
  bool loading = true;
  bool purchasing = false;

  // Discount code
  String discountCode = '';
  bool showDiscountInput = false;
  bool isValidatingCode = false;
  PromotionalOffer? appliedDiscount;
  String? appliedDiscountCode;

  // Close button animation
  bool showCloseButton = false;
  late AnimationController _closeBtnController;
  late Animation<double> _closeBtnOpacity;

  @override
  void initState() {
    super.initState();

    fetchPackages();
    _closeBtnController = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    );
    _closeBtnOpacity = Tween<double>(
      begin: 0,
      end: 1,
    ).animate(_closeBtnController);

    Future.delayed(Duration(seconds: 5), () {
      setState(() => showCloseButton = true);
      _closeBtnController.forward();
    });
  }

  @override
  void dispose() {
    _closeBtnController.dispose();
    super.dispose();
  }

  Future<void> fetchPackages() async {
    setState(() => loading = true);
    try {
      Offerings offerings = await Purchases.getOfferings();
      if (offerings.current != null) {
        packages = offerings.current!.availablePackages;
        // Pre-select weekly if available
        selectedPackage = packages.firstWhere(
          (pkg) =>
              pkg.identifier.toLowerCase().contains('weekly') ||
              pkg.packageType == PackageType.weekly,
          // orElse: () => packages.isNotEmpty ? packages[0] : null,
        );
      }
    } catch (e) {
      // Handle error
    }
    setState(() => loading = false);
  }

  bool hasFreeTrial(Package pkg) {
    final intro = pkg.storeProduct.introductoryPrice;
    if (intro != null) {
      return intro.price == 0;
    }
    return pkg.identifier.toLowerCase().contains('trial') ||
        pkg.identifier.toLowerCase().contains('offer');
  }

  String getTrialDuration(Package pkg) {
    // final intro = pkg.product.introductoryPrice;
    final intro = pkg.storeProduct.introductoryPrice;
    if (intro != null && intro.period != null) {
      final period = intro.period!;
      if (period.contains('P3D')) return '3-Day';
      if (period.contains('P7D')) return '7-Day';
      if (period.contains('P1W')) return '1-Week';
      if (period.contains('P2W')) return '2-Week';
    }
    return '3-Day';
  }

  String getPackagePrice(Package pkg) => pkg.storeProduct.priceString;

  String getPackageDescription(Package pkg) {
    if (pkg.packageType == PackageType.weekly ||
        pkg.identifier.toLowerCase().contains('weekly')) {
      if (hasFreeTrial(pkg)) {
        return 'then ${getPackagePrice(pkg)}/week';
      } else {
        return 'Get Started Now!';
      }
    }
    return 'Best Deal!';
  }

  String getPackageLabel(Package pkg) {
    if (pkg.packageType == PackageType.weekly ||
        pkg.identifier.toLowerCase().contains('weekly')) {
      if (hasFreeTrial(pkg)) {
        return '${getTrialDuration(pkg)} Free Trial';
      } else {
        return 'Weekly';
      }
    }
    return 'Year';
  }

  String getDisplayPrice(Package pkg) {
    if ((pkg.packageType == PackageType.weekly ||
            pkg.identifier.toLowerCase().contains('weekly')) &&
        hasFreeTrial(pkg)) {
      return '\$0.00';
    }
    return getPackagePrice(pkg);
  }

  String getMainTitle() {
    final hasAnyFreeTrial = packages.any((pkg) => hasFreeTrial(pkg));
    if (hasAnyFreeTrial) {
      return 'Unlock full access to\nall features';
    } else {
      return 'Upgrade to Premium\nUnlock all features';
    }
  }

  String getButtonText() {
    if (selectedPackage != null && hasFreeTrial(selectedPackage!)) {
      return 'Start Free Trial';
    } else {
      return 'Continue';
    }
  }

  Future<void> applyDiscountCode() async {
    if (discountCode.trim().isEmpty) {
      _showAlert('Error', 'Please enter a discount code');
      return;
    }
    print(discountCode);
    setState(() => isValidatingCode = true);

    try {
      // First, check if the product has any discounts
      // if (selectedPackage?.storeProduct.discounts == null ||
      //     selectedPackage!.storeProduct.discounts!.isEmpty) {
      //   _showAlert('Error', 'No discounts available for this product');
      //   setState(() => isValidatingCode = false);
      //   return;
      // }
      // print(selectedPackage?.storeProduct.discounts);
      // Try to find the discount, using orElse to handle not found case
      final discount = selectedPackage!.storeProduct.discounts!.firstWhere(
        (d) => d.identifier == discountCode.trim(),
        orElse: () => throw Exception('Discount code not found'),
      );
      print(discount);
      final offer = await Purchases.getPromotionalOffer(
        selectedPackage!.storeProduct,
        discount,
      );

      if (offer != null) {
        setState(() {
          appliedDiscount = offer;
          appliedDiscountCode = discountCode.trim();
          showDiscountInput = false;
        });
        _showAlert('Success', 'Discount code applied successfully!');
      } else {
        _showAlert(
          'Invalid Code',
          'This discount code is not valid or has expired.',
        );
      }
    } catch (e) {
      _showAlert(
        'Invalid Code',
        'This discount code is not valid or available.',
      );
    }

    setState(() => isValidatingCode = false);
  }

  void removeDiscount() {
    setState(() {
      appliedDiscount = null;
      appliedDiscountCode = null;
      discountCode = '';
    });
  }

  Future<void> handlePurchase() async {
    if (selectedPackage == null) return;
    setState(() => purchasing = true);
    try {
      PurchaseResult purchaseResult;
      if (appliedDiscount != null) {
        // Use the new PurchaseParams API for discounted purchases
        final purchaseParams = PurchaseParams.package(
          selectedPackage!,
          promotionalOffer: appliedDiscount!,
        );
        purchaseResult = await Purchases.purchase(purchaseParams);
      } else {
        // Use the new PurchaseParams API for regular purchases
        final purchaseParams = PurchaseParams.package(selectedPackage!);
        purchaseResult = await Purchases.purchase(purchaseParams);
      }

      final customerInfo = purchaseResult.customerInfo;

      if (customerInfo.activeSubscriptions.isNotEmpty) {
        // Optionally send webhook here
        if (!mounted) return;
        Navigator.of(
          context,
        ).pushReplacement(MaterialPageRoute(builder: (_) => HomePage()));
      }
    } on PurchasesErrorCode catch (e) {
      if (e != PurchasesErrorCode.purchaseCancelledError) {
        _showAlert('Error', 'Unable to complete purchase. Please try again.');
      }
    } catch (e) {
      _showAlert('Error', 'Unable to complete purchase. Please try again.');
    }
    setState(() => purchasing = false);
  }

  Future<void> restorePurchases() async {
    setState(() => purchasing = true);
    try {
      final info = await Purchases.restorePurchases();
      if (info.entitlements.active.isNotEmpty) {
        Navigator.of(
          context,
        ).pushReplacement(MaterialPageRoute(builder: (_) => HomePage()));
      } else {
        _showAlert(
          'No purchases found',
          'No active subscriptions were found to restore.',
        );
      }
    } catch (e) {
      _showAlert('Error', 'Unable to restore purchases. Please try again.');
    }
    setState(() => purchasing = false);
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withOpacity(0.7), // Dim background
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: EdgeInsets.symmetric(horizontal: 32, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                Color(0xFF121212),
                Color(0xFF049281).withOpacity(0.15),
                Colors.black,
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Color(0xFF049281), width: 2),
            boxShadow: [
              BoxShadow(
                color: Color(0x80049281),
                blurRadius: 24,
                offset: Offset(0, 8),
              ),
            ],
          ),
          padding: EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Optional: Add a top icon
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: Color(0xFF049281),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Icon(
                    Icons.info_outline,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
              SizedBox(height: 16),
              Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  letterSpacing: 0.5,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 12),
              Text(
                message,
                style: TextStyle(
                  color: Color(0xFF049281),
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  height: 1.4,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF049281),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text(
                    'OK',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildDiscountSection() {
    if (appliedDiscount != null && appliedDiscountCode != null) {
      return Container(
        margin: EdgeInsets.only(bottom: 20),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Color(0x26049281),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Color(0xFF049281), width: 2),
        ),
        child: Row(
          children: [
            Text('🎉', style: TextStyle(fontSize: 24)),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Discount Applied',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                  Text(
                    'Code: $appliedDiscountCode',
                    style: TextStyle(
                      color: Color(0xFF049281),
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            InkWell(
              onTap: removeDiscount,
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: Color(0x33ff4444),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: Color(0xffff4444)),
                ),
                child: Center(
                  child: Text(
                    '×',
                    style: TextStyle(
                      color: Color(0xffff4444),
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    } else if (!showDiscountInput) {
      return Container(
        margin: EdgeInsets.only(bottom: 20),
        child: InkWell(
          onTap: () => setState(() => showDiscountInput = true),
          child: Container(
            padding: EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: Color(0x1A049281),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: Color(0x4D049281),
                width: 1,
                style: BorderStyle.solid,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('🏷️', style: TextStyle(fontSize: 18)),
                SizedBox(width: 8),
                Text(
                  'Have a discount code?',
                  style: TextStyle(
                    color: Color(0xFF049281),
                    fontWeight: FontWeight.w600,
                    fontSize: 15,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    } else {
      return Container(
        margin: EdgeInsets.only(bottom: 20),
        padding: EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Color(0x0D049281),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Color(0xFF049281)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Enter Discount Code',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),
                ),
                InkWell(
                  onTap: () => setState(() => showDiscountInput = false),
                  child: Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Center(
                      child: Text(
                        '×',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    style: TextStyle(color: Colors.white, fontSize: 16),
                    decoration: InputDecoration(
                      hintText: 'Enter code',
                      hintStyle: TextStyle(color: Colors.grey[600]),
                      border: InputBorder.none,
                    ),
                    textCapitalization: TextCapitalization.characters,
                    autocorrect: false,
                    autofocus: true,
                    onChanged: (v) => setState(() => discountCode = v),
                  ),
                ),
                SizedBox(width: 8),
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: discountCode.trim().isEmpty
                        ? Color(0x66049281)
                        : Color(0xFF049281),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    minimumSize: Size(70, 40),
                  ),
                  onPressed: isValidatingCode || discountCode.trim().isEmpty
                      ? null
                      : applyDiscountCode,
                  child: isValidatingCode
                      ? SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        )
                      : Text(
                          'Apply',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                          ),
                        ),
                ),
              ],
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: loading
          ? Center(child: CircularProgressIndicator(color: Color(0xFF049281)))
          : Stack(
              children: [
                // Gradient background
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Color(0xFF049281),
                        Color(0x33000000),
                        Color(0xFF121212),
                        Colors.black,
                      ],
                      stops: [0, 0.6, 0.7, 1],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
                SafeArea(
                  child: Column(
                    children: [
                      // Close button
                      if (showCloseButton)
                        FadeTransition(
                          opacity: _closeBtnOpacity,
                          child: Align(
                            alignment: Alignment.topLeft,
                            child: Padding(
                              padding: const EdgeInsets.only(
                                top: 20,
                                left: 20,
                                bottom: 10,
                              ),
                              child: InkWell(
                                onTap: () =>
                                    Navigator.of(context).pushReplacement(
                                      MaterialPageRoute(
                                        builder: (_) => HomePage(),
                                      ),
                                    ),
                                child: Container(
                                  width: 30,
                                  height: 30,
                                  decoration: BoxDecoration(
                                    color: Colors.black54,
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                  child: Center(
                                    child: Text(
                                      '×',
                                      style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 24,
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      Expanded(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.symmetric(horizontal: 20),
                          child: Column(
                            children: [
                              // SizedBox(height: 40),
                              // Logo
                              Center(
                                child: Image.asset(
                                  'assets/img/Logo.png',
                                  width: 100,
                                  height: 100,
                                ),
                              ),
                              SizedBox(height: 30),
                              // Title
                              Text(
                                getMainTitle(),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                  height: 1.3,
                                ),
                              ),
                              SizedBox(height: 20),
                              // Features
                              Column(
                                children: [
                                  Row(
                                    children: [
                                      Container(
                                        width: 20,
                                        height: 20,
                                        decoration: BoxDecoration(
                                          color: Color(0xFF049281),
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            '✓',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 12),
                                      Text(
                                        'Premium templates',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: 12),
                                  Row(
                                    children: [
                                      Container(
                                        width: 20,
                                        height: 20,
                                        decoration: BoxDecoration(
                                          color: Color(0xFF049281),
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                        child: Center(
                                          child: Text(
                                            '✓',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight.bold,
                                              fontSize: 12,
                                            ),
                                          ),
                                        ),
                                      ),
                                      SizedBox(width: 12),
                                      Text(
                                        'Exclusive filters & effects',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              SizedBox(height: 24),

                              // Pricing options

                              // Pricing options
                              LayoutBuilder(
                                builder: (context, constraints) {
                                  // Calculate the width for each card (subtracting margin)
                                  final cardWidth = constraints.maxWidth * 0.45;
                                  return Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: packages.map((pkg) {
                                      final isSelected =
                                          selectedPackage?.identifier ==
                                          pkg.identifier;
                                      return Container(
                                        width: cardWidth,
                                        margin: EdgeInsets.symmetric(
                                          horizontal: 6,
                                        ),
                                        child: GestureDetector(
                                          onTap: purchasing
                                              ? null
                                              : () => setState(() {
                                                  selectedPackage = pkg;
                                                  handlePurchase();
                                                }),
                                          child: AnimatedContainer(
                                            duration: Duration(
                                              milliseconds: 200,
                                            ),
                                            padding: EdgeInsets.all(16),
                                            decoration: BoxDecoration(
                                              color: isSelected
                                                  ? Color(0x28049281)
                                                  : Colors.white10,
                                              borderRadius:
                                                  BorderRadius.circular(16),
                                              border: Border.all(
                                                color: isSelected
                                                    ? Color(0xFF049281)
                                                    : Colors.transparent,
                                                width: 2,
                                              ),
                                              boxShadow: isSelected
                                                  ? [
                                                      BoxShadow(
                                                        color: Color(
                                                          0x80049281,
                                                        ),
                                                        blurRadius: 16,
                                                        offset: Offset(0, 6),
                                                      ),
                                                    ]
                                                  : [],
                                            ),
                                            child: Stack(
                                              children: [
                                                if (isSelected)
                                                  Positioned(
                                                    top: 0,
                                                    right: 0,
                                                    child: Container(
                                                      width: 24,
                                                      height: 24,
                                                      decoration: BoxDecoration(
                                                        color: Color(
                                                          0xFF049281,
                                                        ),
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                              12,
                                                            ),
                                                      ),
                                                      child: Center(
                                                        child: Text(
                                                          '✓',
                                                          style: TextStyle(
                                                            color: Colors.white,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                            fontSize: 12,
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      getPackageLabel(pkg),
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 13,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                                    ),
                                                    SizedBox(height: 8),
                                                    Text(
                                                      getDisplayPrice(pkg),
                                                      style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 24,
                                                        fontWeight:
                                                            FontWeight.bold,
                                                      ),
                                                    ),
                                                    SizedBox(height: 6),
                                                    Text(
                                                      getPackageDescription(
                                                        pkg,
                                                      ),
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: TextStyle(
                                                        color: Color(
                                                          0xFF049281,
                                                        ),
                                                        fontSize: 10,
                                                        fontWeight:
                                                            FontWeight.w500,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                  );
                                },
                              ),

                              SizedBox(height: 20),
                              // Discount code section
                              buildDiscountSection(),
                              // Purchase button
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Color(0xFF049281),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(25),
                                    ),
                                    padding: EdgeInsets.symmetric(vertical: 18),
                                  ),
                                  onPressed:
                                      purchasing || selectedPackage == null
                                      ? null
                                      : handlePurchase,
                                  child: purchasing
                                      ? SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: CircularProgressIndicator(
                                            color: Colors.white,
                                            strokeWidth: 2,
                                          ),
                                        )
                                      : Text(
                                          getButtonText(),
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                ),
                              ),
                              SizedBox(height: 24),
                              // Footer links
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  TextButton(
                                    onPressed: () => launchUrl(
                                      Uri.parse(
                                        'https://eyeshealthtest.com/terms.html',
                                      ),
                                    ),
                                    child: Text(
                                      'Terms',
                                      style: TextStyle(
                                        color: Color(0xFF049281),
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: restorePurchases,
                                    child: Text(
                                      'Restore',
                                      style: TextStyle(
                                        color: Color(0xFF049281),
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                  TextButton(
                                    onPressed: () => launchUrl(
                                      Uri.parse(
                                        'https://eyeshealthtest.com/privacy.html',
                                      ),
                                    ),
                                    child: Text(
                                      'Privacy',
                                      style: TextStyle(
                                        color: Color(0xFF049281),
                                        fontSize: 16,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 20),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

class PaywallPackageCard extends StatelessWidget {
  final Package package;
  final bool isSelected;
  final VoidCallback? onTap;
  final String label;
  final String price;
  final String description;
  final bool isBest;

  const PaywallPackageCard({
    required this.package,
    required this.isSelected,
    required this.onTap,
    required this.label,
    required this.price,
    required this.description,
    this.isBest = false,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        // width: 160,
        padding: EdgeInsets.all(18),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: [Color(0xFF049281), Color(0xFF0E3C36)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : LinearGradient(
                  colors: [Colors.white10, Colors.black12],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: Color(0x80049281),
                    blurRadius: 18,
                    offset: Offset(0, 8),
                  ),
                ]
              : [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 8,
                    offset: Offset(0, 4),
                  ),
                ],
          border: Border.all(
            color: isSelected ? Color(0xFF049281) : Colors.transparent,
            width: 2,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (isBest)
              Container(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Color(0xFF049281),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  'Best Value',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            SizedBox(height: isBest ? 10 : 0),
            Icon(
              Icons.star_rounded,
              color: isSelected ? Colors.yellow[700] : Colors.white24,
              size: 32,
            ),
            SizedBox(height: 10),
            Text(
              label,
              style: TextStyle(
                color: Colors.white,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 8),
            Text(
              price,
              style: TextStyle(
                color: Colors.white,
                fontSize: 26,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 6),
            Text(
              description,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Color(0xFF049281),
                fontSize: 13,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
