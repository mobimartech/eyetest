import 'dart:convert';
import 'dart:io';

import 'package:eyetest/home.dart';
import 'package:eyetest/splashscreen.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:appsflyer_sdk/appsflyer_sdk.dart';
import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:purchases_flutter/purchases_flutter.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late AppsflyerSdk _appsflyerSdk;
  bool _attGranted = false;
  bool _hasProcessedAttribution = false;
  String _status = "Initializing...";
  String? _appsflyerUID;
  String? _appVersion;
  String? _platformVersion;
  Future<void> initRevenueCat() async {
    await Purchases.setLogLevel(LogLevel.debug); // Optional: for debugging
    await Purchases.configure(
      PurchasesConfiguration("appl_HLNlRmifZJLrajFZwzSWgBNvflh"),
    );
  }

  @override
  void initState() {
    super.initState();
    _initApp();
  }

  Future<void> _initApp() async {
    await initRevenueCat();
    await _getAppVersion();
    await _getPlatformVersion();
    await _requestATT();
    _initAppsFlyer();
  }

  Future<void> _getAppVersion() async {
    final info = await PackageInfo.fromPlatform();
    setState(() {
      _appVersion = info.version;
    });
  }

  Future<void> _getPlatformVersion() async {
    final deviceInfo = DeviceInfoPlugin();
    if (Platform.isAndroid) {
      final androidInfo = await deviceInfo.androidInfo;
      _platformVersion = androidInfo.version.release;
    } else if (Platform.isIOS) {
      final iosInfo = await deviceInfo.iosInfo;
      _platformVersion = iosInfo.systemVersion;
    }
  }

  Future<void> _requestATT() async {
    if (Platform.isIOS) {
      final status = await AppTrackingTransparency.trackingAuthorizationStatus;
      if (status == TrackingStatus.notDetermined) {
        final result =
            await AppTrackingTransparency.requestTrackingAuthorization();
        _attGranted = result == TrackingStatus.authorized;
      } else {
        _attGranted = status == TrackingStatus.authorized;
      }
    } else {
      _attGranted = true; // Android doesn't need ATT
    }
    setState(() {});
  }

  void _initAppsFlyer() {
    final options = AppsFlyerOptions(
      afDevKey: 'FjSERtDKGm29LmgGqGBpdn',
      appId: Platform.isIOS ? '6621183937' : "",
      showDebug: true,
      timeToWaitForATTUserAuthorization: 60,
    );
    _appsflyerSdk = AppsflyerSdk(options);

    _appsflyerSdk.initSdk(
      registerConversionDataCallback: true,
      registerOnAppOpenAttributionCallback: true,
      registerOnDeepLinkingCallback: true,
    );

    _appsflyerSdk.getAppsFlyerUID().then((uid) {
      setState(() {
        _appsflyerUID = uid;
      });
    });

    _appsflyerSdk.onInstallConversionData((data) async {
      if (_hasProcessedAttribution) return;
      _hasProcessedAttribution = true;
      final extracted = _extractOneLinkParams(data);
      if (data['data']?['is_first_launch'] == true) {
        await _sendOneLinkDataToWebhook(
          extractedParams: extracted,
          eventType: 'first_open_after_install',
          rawAppsFlyerData: data,
        );
        setState(() {
          _status = "Install conversion sent!";
        });
      }
    });

    _appsflyerSdk.onDeepLinking((deepLinkResult) async {
      final extracted = _extractOneLinkParams(deepLinkResult.toJson());
      await _sendOneLinkDataToWebhook(
        extractedParams: extracted,
        eventType: 'deep_link_open',
        rawAppsFlyerData: deepLinkResult.toJson(),
      );
      setState(() {
        _status = "Deep link sent!";
      });
    });
  }

  Map<String, dynamic> _extractOneLinkParams(Map data) {
    final d = data['data'] ?? {};
    String? decode(dynamic v) =>
        v == null ? null : Uri.decodeComponent(v.toString());

    String? clickId = decode(d['e_token']);
    if (clickId == '{Click_ID}' || clickId == '%7BClick_ID%7D') {
      clickId = 'placeholder_click_id_${DateTime.now().millisecondsSinceEpoch}';
    }
    String? eventName = decode(d['e_value']);
    if (eventName == '{Event_name}' || eventName == '%7BEvent_name%7D') {
      eventName = 'app_open';
    }
    String? eventValue = decode(d['adn_tid']);
    if (eventValue == '{Event_value}' || eventValue == '%7BEvent_value%7D') {
      eventValue = '1';
    }
    String? cn = decode(d['cn']);
    if (cn == '{cn}' || cn == '%7Bcn%7D') {
      cn = 'organic_campaign';
    }

    return {
      'cn': cn,
      'af_xp': decode(d['af_xp']),
      'pid': decode(d['pid']),
      'media_source': d['media_source']?.toString(),
      'click_id': clickId,
      'event_name': eventName,
      'event_value': eventValue,
      'af_status': d['af_status']?.toString(),
      'af_message': d['af_message']?.toString(),
      'campaign': d['campaign']?.toString(),
      'channel': d['channel']?.toString(),
      'deep_link_value': decode(d['deep_link_value']),
      'deep_link_sub1': decode(d['deep_link_sub1']),
      'deep_link_sub2': decode(d['deep_link_sub2']),
      'deep_link_sub3': decode(d['deep_link_sub3']),
      'att_permission_granted': _attGranted,
      'att_status': _attGranted ? 'authorized' : 'denied_or_restricted',
    };
  }

  Future<void> _sendOneLinkDataToWebhook({
    required Map<String, dynamic> extractedParams,
    required String eventType,
    required Map rawAppsFlyerData,
  }) async {
    const webhookUrl = 'https://eyeshealthtest.com/webhook/index.php';
    final payload = {
      "test_mode": false,
      "event_type": eventType,
      "timestamp": DateTime.now().toIso8601String(),
      "onelink_params": {
        "cn": extractedParams["cn"],
        "af_xp": extractedParams["af_xp"],
        "pid": extractedParams["pid"],
        "e_token": extractedParams["click_id"],
        "e_value": extractedParams["event_name"],
        "adn_tid": extractedParams["event_value"],
        "deep_link_sub1": extractedParams["deep_link_sub1"],
        "deep_link_sub2": extractedParams["deep_link_sub2"],
        "deep_link_sub3": extractedParams["deep_link_sub3"],
      },
      "attribution_data": {
        "af_status": extractedParams["af_status"] ?? "Unknown",
        "af_message": extractedParams["af_message"] ?? "",
        "media_source":
            extractedParams["media_source"] ??
            extractedParams["pid"] ??
            "organic",
        "campaign": extractedParams["campaign"],
        "channel": extractedParams["channel"],
        "att_permission_granted": _attGranted,
        "att_status": _attGranted ? "authorized" : "denied_or_restricted",
      },
      "device_info": {
        "platform": Platform.operatingSystem,
        "platform_version": _platformVersion ?? "unknown",
        "app_version": _appVersion ?? "unknown",
        "appsflyer_uid": _appsflyerUID,
        "att_permission_granted": _attGranted,
      },
      "raw_appsflyer_data": rawAppsFlyerData,
    };

    final response = await http.post(
      Uri.parse(webhookUrl),
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'AIScanPro/${Platform.operatingSystem}/1.0',
        'Accept': 'application/json',
      },
      body: jsonEncode(payload),
    );
    // Optionally handle response here
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My Flutter App',
      home: SplashScreen(),
    );
  }
}
